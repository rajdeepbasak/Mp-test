/**
 * 
 */
package com.ups.ttg.flight.acars.message.parser.exception;

/**
 * @author 482800
 *
 */
public class ObjectBuilderException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = -7612400850180039517L;

    public ObjectBuilderException() {
        super();

    }

    public ObjectBuilderException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public ObjectBuilderException(String message, Throwable cause) {
        super(message, cause);
    }

    public ObjectBuilderException(String message) {
        super(message);
    }

    public ObjectBuilderException(Throwable cause) {
        super(cause);
    }

}
