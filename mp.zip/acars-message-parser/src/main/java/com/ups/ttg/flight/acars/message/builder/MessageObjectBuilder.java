package com.ups.ttg.flight.acars.message.builder;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.logging.Logger;

import org.apache.commons.beanutils.BeanUtils;

import com.ups.ttg.flight.acars.message.parser.exception.ObjectBuilderException;

public class MessageObjectBuilder<T> {
    private static final Logger log = Logger.getLogger(MessageObjectBuilder.class.getName());
    private static List<String> premitiveList = Arrays.asList("int", "float", "java.lang.String");
    private final Class<T> clazz;

    public MessageObjectBuilder(Class<T> type) {
        this.clazz = type;
    }

    /**
     * Builds the Object from Map
     * 
     * @param values
     * @return
     * @throws ObjectBuilderException
     */
    public T buildObject(Map<String, String> values) throws ObjectBuilderException {
        T object = null;
        try {
            Constructor<T> ctor = clazz.getConstructor();
            object = ctor.newInstance();
            // Getting full path for the properties
            Map<String, String> propertyPathMap = getAllPropertyDetails();
            // logging the path for all the propety
            propertyPathMap.forEach((k, v) -> log.info(k + "(" + v.split("\\.").length + ") : " + v));
            setPropertyValues(object, propertyPathMap, values);
        } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException
                | IllegalArgumentException | InvocationTargetException e) {
            String message = "Can not Create Object Exception Occured";
            log.info(message);
            throw new ObjectBuilderException(message, e);
        }
        return object;
    }

    private void setPropertyValues(T object, Map<String, String> propertyPathMap, Map<String, String> values) {
        propertyPathMap.forEach((k, v) -> setProperty(object, k, v, values));
    }

    /**
     * Set Property
     * 
     * @param object
     * @param propName
     * @param propertyPath
     * @param values
     * @return
     */
    private Object setProperty(Object object, String propName, String propertyPath, Map<String, String> values) {
        Class<?> objClass = object.getClass();
        if (propertyPath.equals(propName)) {
            try {
                BeanUtils.setProperty(object, propName, values.get(propName));
            } catch (IllegalAccessException | InvocationTargetException e) {
                log.info("Can not set property : " + propName);
                return object;
            }
        } else {
            try {
                String nextLevelPropertyName = propertyPath.split("\\.")[0];
                if (BeanUtils.getProperty(object, nextLevelPropertyName) == null) {
                    setNewObject(object, nextLevelPropertyName);
                }
                Field field = objClass.getDeclaredField(nextLevelPropertyName);
                field.setAccessible(true);
                Object nextLevelObject = field.get(object);
                String newPropertyPath = propertyPath.substring(propertyPath.indexOf(".") + 1);
                setProperty(nextLevelObject, propName, newPropertyPath, values);
            } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException | NoSuchFieldException
                    | SecurityException | IllegalArgumentException | InstantiationException e) {
                log.info(() -> "Can not set property" + propName);
                log.info(() -> "Some field is not accessible in " + objClass.getName());
                log.info(e.getMessage());
                return object;
            }
        }
        return object;
    }

    /**
     * Sets New Object
     * 
     * @param object
     * @param nextLevelPropertyName
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws InstantiationException
     * @throws NoSuchMethodException
     * @throws NoSuchFieldException
     */
    private void setNewObject(Object object, String nextLevelPropertyName) throws IllegalAccessException,
            InvocationTargetException, InstantiationException, NoSuchMethodException, NoSuchFieldException {
        Class<?> objClass = object.getClass();
        Class<?> fieldClass = objClass.getDeclaredField(nextLevelPropertyName).getType();
        Constructor<?> ctor = fieldClass.getConstructor();
        Object fieldObject = ctor.newInstance();
        BeanUtils.setProperty(object, nextLevelPropertyName, fieldObject);
    }

    /**
     * Get All Property Details
     * 
     * @return Map<String, String>
     */
    private Map<String, String> getAllPropertyDetails() {
        List<Field> fieldList = Arrays.asList(clazz.getDeclaredFields());
        Map<String, String> properties = new HashMap<>();
        fieldList.forEach(e -> properties.putAll(getPropertyMap(e, new StringJoiner("."))));
        return properties;
    }

    /**
     * Gets the Property Map for the Field and fieldPath
     * 
     * @param field
     * @param fieldPath
     * @return Map<String, String>
     */
    private Map<String, String> getPropertyMap(Field field, StringJoiner fieldPath) {
        String fieldName = field.getName();
        Map<String, String> propertyMap = new HashMap<>();
        if (premitiveList.contains(field.getType().getName())) {
            String fullFieldPath = fieldPath.toString().equals("") ? fieldName : fieldPath.toString() + "." + fieldName;
            propertyMap.put(fieldName, fullFieldPath);
        } else {
            StringJoiner nextLevelFieldPath = new StringJoiner(".");
            nextLevelFieldPath.merge(fieldPath);
            nextLevelFieldPath.add(fieldName);
            Arrays.asList(field.getType().getDeclaredFields())
                    .forEach(e -> propertyMap.putAll(getPropertyMap(e, nextLevelFieldPath)));
        }
        return propertyMap;
    }
}
