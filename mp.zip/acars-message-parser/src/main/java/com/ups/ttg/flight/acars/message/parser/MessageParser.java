package com.ups.ttg.flight.acars.message.parser;

import static com.ups.ttg.flight.acars.domain.SMIValue.DRY_ICE_TO_PRINTER;
import static com.ups.ttg.flight.acars.domain.constant.MessageFieldConstants.LINE_SEPARATOR;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ups.ttg.flight.acars.message.parser.exception.ParserException;
import com.ups.ttg.flight.acars.message.parser.vo.DataField;
import com.ups.ttg.flight.acars.message.parser.vo.MessageFormat;

import lombok.Setter;

/**
 * This class contains methods to parse a ACARS message. Also there is a method
 * which will build the message.
 * 
 * @author 509202
 *
 */
public class MessageParser {

    public static final String FIELD_LENGTH_ERROR = "Field length Error";
    public static final String FIELD_FORMAT_ERROR = "Field Format Error";
    public static final String PREFIX_ERROR = "Prefix error";
    public static final String END_OF_LINE_ERROR = "End of line error";

    private static final String GROUND_STATION = "groundStation";
    private static final String SPACE = " ";
    
    private static final String AID0000051 = "AID0000051";
    private static final String AID0000053 = "AID0000053";
    private static final String DISPATCHER = "DISPATCHER";
    private static final String M37FORCERTIFICATION = "M37FORCERTIFICATION";
    
    private static final String TEBPD5X = "TEBPD5X";
    
    private static final String M4F = "M4F";
    private static final String M4G = "M4G";
    private static final String M4H = "M4H";
    private static final String M4I = "M4I";
    private static final String M4J = "M4J";
    private static final String M4K = "M4K";
    private static final String M4L = "M4L";
    private static final String M4M = "M4M";
    private static final String M4N = "M4N";
    private static final String M4P = "M4P";
    private static final String CFD = "CFD";
    private static final String M38 = "M38";
    private static final String ETC = "ETC";
    private static final String ETR = "ETR";
    private static final String M3D = "M3D";
    private static final String M3V = "M3V";
    private static final String M3Y = "M3Y";
    private static final String PBC = "PBC";
    private static final String M30 = "M30";
    private static final String MED = "MED";
    private static final String OAT = "OAT";
    private static final String PBR = "PBR";
    private static final String RAI = "RAI";
    private static final String REJ = "REJ";
    private static final String TIS = "TIS";
    private static final String M19 = "M19";
    private static final String CLA = "CLA";
    private static final String RCL = "RCL";
    private static final String CLD = "CLD";
    private static final String FMR = "FMR";
    private static final String FML = "FML";
    private static final String FMD = "FMD";
    private static final String MAS = "MAS";
    private static final String PDC = "PDC";
    private static final String PLW = "PLW";
    private static final String SVC = "SVC";
    private static final String M3T ="M3T";
    private static final String M3X ="M3X"; 
    private static final String M37 ="M37"; 
    private static final String M41 ="M41"; 
    private static final String M3P ="M3P"; 
    private static final String M36 ="M36";
    private static final String  DFDUplinkHeader = "DFDUplinkHeader";
    
    private static final String HEADER_FOR_PDC = "HeaderFormatForPDC.json";
    private static final String HEADER_FOR_M37_CITIFICATION = "HeaderFormatForCertificationM37.json";
    private static final String HEADER_FOR_M4I = "HeaderFormatForM4I.json";
    private static final String HEADER_FOR_FPAS = "HeaderFormatForFPAS.json";
    private static final String HEADER_FOR_TIS = "HeaderFormatForTIS.json";
    private static final String HEADER_FOR_MAS = "HeaderFormatForMAS.json";
    private static final String HEADER_FOR_UPLINK = "HeaderFormatForUplink.json";
    private static final String HEADER_FORMAT = "HeaderFormat.json";

    private static final Logger log = Logger.getLogger(MessageParser.class.getName());

    private static final List<String> noFormatList = Arrays.asList(M4F, M4G, M4H, M4I, M4J, M4K, M4L,
            M4M, M4N, M4P, CFD, M38, ETC, ETR, M3D, M3V, M3Y, PBC, M30, MED,
            OAT, PBR, RAI, REJ, TIS, M19, CLA, RCL, CLD, FMR, FML, FMD, MAS);

    @Setter
    private String lineSeprator = LINE_SEPARATOR;

    @Setter
    private String fileNamePostfix = "Format.json";

    private static final String END_OF_LINE_REGEX = "(\\r\\n)|(\\r)|(\\n)";

    private List<DataField> headerFieldList;
    private MessageFormat messageFormat;
    private Map<String, String> errorMap = new HashMap<>();

    private String inputMessage;
    private String header;
    private String text;
    private boolean isShortGroundStation = false;

    public MessageParser() {

    }

    public Map<String, String> getErrorMap() {
        return errorMap;
    }

    public void setErrorMap(Map<String, String> errorMap) {
        this.errorMap = errorMap;
    }

    /**
     * Constructor for creating Parser object.
     * 
     * @param smi:
     *            SMI code for which the object will be created.
     * @throws ParserException
     */
    public MessageParser(String smi) throws ParserException {
        super();
        this.headerFieldList = getHeaderFields(smi);
        this.messageFormat = getMessageFormat(smi);
    }

    /**
     * Constructor for creating Parser object.
     * 
     * @param smi:
     *            SMI code for which the object will be created.
     * @throws ParserException
     */
    public MessageParser(String smiHeader, String smiFromat) throws ParserException {
        super();
        this.headerFieldList = getHeaderFields(smiHeader);
        this.messageFormat = getMessageFormat(smiFromat);
    }

    /**
     * This method is used to get SMI code from a given message
     * 
     * @param rawMessage
     * @return
     */
    public static String getSMI(String rawMessage) {
        String smi = "";
        if (rawMessage.substring(3, 10).equals(TEBPD5X)) {
            smi = PDC;
        } else if (rawMessage.length() > 50 && rawMessage.substring(47, 50).equals(PLW)) {
            smi = PLW;
        } else if (StringUtils.equalsIgnoreCase(StringUtils.substring(rawMessage, 10, 20), AID0000051)) {
            smi = AID0000051;
        } else if (StringUtils.equalsIgnoreCase(StringUtils.substring(rawMessage, 10, 20), AID0000053)) {
            smi = AID0000053;
        } else {
            String lineSeparator = LINE_SEPARATOR;
            String message = StringUtils.replacePattern(rawMessage, END_OF_LINE_REGEX, lineSeparator);
            int endOfSecondLineIndex = StringUtils.ordinalIndexOf(message, lineSeparator, 2);
            int endOfThirdLineIndex = StringUtils.ordinalIndexOf(message, lineSeparator, 3);

            smi = StringUtils.substring(message, endOfSecondLineIndex, endOfThirdLineIndex);

            smi = StringUtils.replace(smi, lineSeparator, "").trim();
        }
        return smi;
    }

    /**
     * @param fileName
     * @throws ParserException
     */
    public void getAllMessageFields(String fileName) throws ParserException {
        this.headerFieldList = new ArrayList<>();
        this.messageFormat = getMessageFormat(fileName);
    }

    /**
     * This Method parse the Message.
     * 
     * @param input
     * @return
     */
    public List<DataField> parse(String input) {
        log.info("Parsing Raw Message :");
        // replacing Platform dependent line separator with the line separator for
        // executing environment
        this.inputMessage = StringUtils.replacePattern(input, END_OF_LINE_REGEX, lineSeprator);
        splitHeaderAndMessage();

        // For each header fields parsing the value
        this.isShortGroundStation = false;
        this.headerFieldList.stream().forEach(this::parseHeader);
        // For each text fields parsing the value
        this.messageFormat.getDataFieldList().stream().forEach(this::parseField);

        // concatenating all the fields detail in header as well as text and returns the
        // list
        return Stream.concat(this.headerFieldList.stream(), this.messageFormat.getDataFieldList().stream())
                .collect(Collectors.toList());

    }

    /**
     * This method Build the message from a supplied object. Using their structure
     * stored in JSON file
     * 
     * @param object
     * @return
     */
    public String build(Object object) {
        log.info("Building Raw message");
        StringBuilder rawMessage = new StringBuilder();
        // Merging the headerfields as well as message fields
        List<DataField> dataFields = Stream
                .concat(this.headerFieldList.stream(), this.messageFormat.getDataFieldList().stream())
                .collect(Collectors.toList());
        // for each fields we get the token and concatenate to build the message
        dataFields.stream().forEach(d -> rawMessage.append(getToken(object, d)));
        return rawMessage.toString();
    }

    /**
     * This method will read JSON file for the header and return all the
     * {@link DataField} for the Header section. It will select the Header json
     * according to smi as for different smi header format is different
     * 
     * @param smi
     * @return
     * @throws ParserException
     */
    public List<DataField> getHeaderFields(String smi) throws ParserException {
        List<DataField> fieldList = new ArrayList<>();
        try {
            String jsonString = "";
            List<String> smiListWithFpasHeader = new LinkedList<>(
                    Arrays.asList(M3T,M3X, M37, M41, M3P, DFDUplinkHeader, M36));
            List<String> smiListWithTisHeader = new LinkedList<>(Arrays.asList(TIS, SVC));
            List<String> smiListWithMasHeader = new LinkedList<>(Arrays.asList(M4G));
            List<String> smiListWithM4iHeader = new LinkedList<>(Arrays.asList(M4I, MAS));
            List<String> smiListWithUplinkHeader = new LinkedList<>(
                    Arrays.asList(M4F, M4G, M4H, M4J, M4K, M4L));
            List<String> smiListWithBlankHeader = new LinkedList<>(Arrays.asList(PLW, AID0000051, AID0000053,
                    DISPATCHER, DRY_ICE_TO_PRINTER.getValue().toUpperCase()));
            List<String> smiListWithCeritificationHeader = new LinkedList<>(Arrays.asList(M37FORCERTIFICATION));

            // Select Header For Specified SMI
            if (smiListWithBlankHeader.contains(smi.toUpperCase())) {
                return fieldList;
            } else if (StringUtils.equalsIgnoreCase(smi, PDC)) {
                jsonString = getFileContent(HEADER_FOR_PDC);
            } else if (smiListWithCeritificationHeader.contains(smi.toUpperCase())) {
                jsonString = getFileContent(HEADER_FOR_M37_CITIFICATION);
            } else if (smiListWithM4iHeader.contains(smi.toUpperCase())) {
                jsonString = getFileContent(HEADER_FOR_M4I);
            } else if (smiListWithFpasHeader.contains(smi.toUpperCase())) {
                jsonString = getFileContent(HEADER_FOR_FPAS);
            } else if (smiListWithTisHeader.contains(smi.toUpperCase())) {
                jsonString = getFileContent(HEADER_FOR_TIS);
            } else if (smiListWithMasHeader.contains(smi.toUpperCase())) {
                jsonString = getFileContent(HEADER_FOR_MAS);
            } else if (smiListWithUplinkHeader.contains(smi.toUpperCase())) {
                jsonString = getFileContent(HEADER_FOR_UPLINK);
            } else {
                jsonString = getFileContent(HEADER_FORMAT);
            }

            ObjectMapper objectMapper = new ObjectMapper();
            fieldList = objectMapper.readValue(jsonString,
                    objectMapper.getTypeFactory().constructCollectionType(List.class, DataField.class));
        } catch (IOException e) {
            String message = "Unable to read not read fromat file";
            log.info(message);
            throw new ParserException(message, e);
        }
        return fieldList;
    }

    /**
     * Read file content
     * 
     * @param fileName
     * @return
     * @throws ParserException
     */
    private String getFileContent(String fileName) throws ParserException {
        log.info("Trying to locate file ==>" + fileName);
        try (InputStream systemResourceAsStream = MessageParser.class.getResourceAsStream("/" + fileName);) {

            return new BufferedReader(new InputStreamReader(systemResourceAsStream)).lines()
                    .collect(Collectors.joining("\n"));
        } catch (Exception e) {

            throw new ParserException("Unable to read file :" + fileName, e);
        }
    }

    /**
     * This method will read JSON file according to the SMI code and return
     * {@link MessageFormat} which will contain the field description for all the
     * fields in the text of the message.
     * 
     * @param smi
     * @return
     * @throws ParserException
     */
    public MessageFormat getMessageFormat(String smi) throws ParserException {
        String jsonString;
        MessageFormat fmt = null;
        try {
            if (noFormatList.contains(smi)) {

                jsonString = getFileContent("No" + fileNamePostfix);
            } else {
                log.info("The File name ==>" + smi + fileNamePostfix);
                jsonString = getFileContent(smi + fileNamePostfix);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            fmt = objectMapper.readValue(jsonString, MessageFormat.class);
        } catch (IOException e) {
            throw new ParserException("Unable to read not read fromat file", e);
        }
        return fmt;
    }

    /**
     * This method Split the header and text message and store it in class level
     * variable.
     * 
     */
    private void splitHeaderAndMessage() {
        // Counting Number of Lines in the Header
        long lineCount = headerFieldList.stream().filter(DataField::isEndOfLine).count();
        // Determining the Index of the end of the header
        int headerEndIndex = StringUtils.ordinalIndexOf(this.inputMessage, lineSeprator, (int) lineCount);
        if (headerEndIndex > -1) {
            headerEndIndex += lineSeprator.length();
        } else {
            headerEndIndex = 0;
        }

        this.header = StringUtils.substring(this.inputMessage, 0, headerEndIndex);

        this.text = StringUtils.substring(this.inputMessage, headerEndIndex);
    }

    /**
     * This Method parse the header fields
     * 
     * @param field
     */
    private void parseHeader(DataField field) {
        /*
         * If the field is ground station its length may be 3 or 4, accordingly we also
         * have to adjust the position for the following Fields also
         */
        if (isShortGroundStation || StringUtils.equals(field.getFieldName(), GROUND_STATION)) {
            adjustDataFieldLengthAndPosition(field);
        }
        int fieldLength = field.getFieldLength() + field.getSeparatedBy().length();
        int tokenCount = header.indexOf(lineSeprator) >= 0 ? header.indexOf(lineSeprator) : header.length();
        if (fieldLength > tokenCount) {
            // if the field length is wrong but after the field new line starts then pointer
            // will move to new line
            field.setValue(StringUtils.substring(this.header, 0, tokenCount));
            this.header = StringUtils.substring(this.header, fieldLength);
            log.info(() -> field.getFieldName() + " : " + FIELD_LENGTH_ERROR);
            this.errorMap.put(field.getFieldName(), FIELD_LENGTH_ERROR);
        } else {
            String token = StringUtils.substring(this.header, 0, fieldLength);
            this.header = StringUtils.substring(this.header, fieldLength);
            if (token.startsWith(field.getSeparatedBy())) {
                token = StringUtils.replaceOnce(token, field.getSeparatedBy(), "");
                if (StringUtils.isNotBlank(field.getFormat()) && !Pattern.matches(field.getFormat(), token)) {
                    this.errorMap.put(field.getFieldName(), FIELD_FORMAT_ERROR);
                }
                field.setValue(token);
            } else {
                this.errorMap.put(field.getFieldName(), PREFIX_ERROR);
            }
        }
        if (field.isEndOfLine()) {
            if (StringUtils.indexOf(this.header, lineSeprator) != 0) {
                this.errorMap.put(field.getFieldName(), END_OF_LINE_ERROR);
            }
            moveToNextLine();
        }
    }

    /**
     * This Method adjusts the ground station length and the position for the fields
     * after goundStation
     * 
     * @param field
     */
    private void adjustDataFieldLengthAndPosition(DataField field) {
        if (StringUtils.equals(field.getFieldName(), "groundStation")) {
            String token = StringUtils.substring(this.header, 0, 6);
            if (SPACE.equals(StringUtils.substring(token, 4, 5)) && !SPACE.equals(StringUtils.substring(token, 5, 6))) {
                this.isShortGroundStation = true;
                int previousFieldLength = field.getFieldLength();
                field.setFieldLength(--previousFieldLength);
            }
        } else if (this.isShortGroundStation) {
            int previousFieldPosition = field.getFieldPosition();
            field.setFieldPosition(--previousFieldPosition);
        }
    }

    /**
     * Move the pointer to next line. Some fields are starts in new line.
     */
    private void moveToNextLine() {
        int nextLineIndex = header.indexOf(lineSeprator) + lineSeprator.length();
        if (this.header.length() > 0) {
            this.header = StringUtils.substring(this.header, nextLineIndex);
        }

    }

    /**
     * Parse the fields in text message
     * 
     * @param field
     */
    private void parseField(DataField field) {
        int position = field.getFieldPosition();
        if (position > this.text.length() && !field.isOptional()) {
            this.errorMap.put("messageLenthError", "Some Mendatory fields are not Presnt in Message");
            log.info("Some Mendatory fields are not Presnt in Message");
        } else if (position > this.text.length() && field.isOptional()) {
            return;
        } else if (position + field.getFieldLength() - 1 > this.text.length() && !field.isOptional()) {
            this.errorMap.put(field.getFieldName(), FIELD_LENGTH_ERROR);
        } else {
            String token = field.getFieldLength() == 0 ? StringUtils.substring(this.text, position - 1)
                    : StringUtils.substring(this.text, position - 1, position + field.getFieldLength() - 1);
            field.setValue(token);
            if (StringUtils.isNotBlank(field.getFormat()) && !Pattern.matches(field.getFormat(), token)) {
                this.errorMap.put(field.getFieldName(), FIELD_FORMAT_ERROR);
            }
            log.info(() -> field.getFieldName() + " : [" + token + "]");
        }
    }

    /**
     * This method return the value to be set in the message template for a given
     * field from the supplied object.
     * 
     * @param object
     * @param field
     * @return
     */
    private String getToken(Object object, DataField field) {
        String value;
        StringBuilder token = new StringBuilder();
        try {
            value = getfieldValue(object, field);
            if (StringUtils.isNotBlank(value)) {
                token.append(field.getSeparatedBy()).append(getFieldValueWithAlignment(value.trim(), field));

            } else if (!field.isOptional()) {
                Optional<String> defaultChar = Optional.ofNullable(field.getDefaultCharacter());
                token.append(StringUtils.repeat(defaultChar.map(s -> s).orElse(SPACE), field.getFieldLength()));
            }

            if (field.isEndOfLine()) {
                token.append(lineSeprator);
            }
            if (!StringUtils.isEmpty(field.getSuffix())) {
                token.append(field.getSuffix());
            }
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException | NoSuchFieldException e) {
            String message = field.getFieldName() + " : Not found in canonical message";
            log.info(message);
            return "";
        }
        return token.toString();
    }

    /**
     * get a field value from a object. in this case if a value is not find in the
     * object then try to get the value from acarsMessageHeader object
     * 
     * @param object
     * @param field
     * @return
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws NoSuchMethodException
     * @throws NoSuchFieldException
     * @throws SecurityException
     */
    private String getfieldValue(Object object, DataField field)
            throws IllegalAccessException, InvocationTargetException, NoSuchMethodException, NoSuchFieldException {
        String value = "";
        try {
            value = BeanUtils.getProperty(object, field.getFieldName());
        } catch (Exception e) {
            Field headerField = object.getClass().getDeclaredField("acarsMessageHeader");
            headerField.setAccessible(true);
            Object headerObject = headerField.get(object);
            value = BeanUtils.getProperty(headerObject, field.getFieldName());
            return value;
        }
        return value;
    }

    /**
     * This method aligns the value of a field
     * 
     * @param value
     * @param d
     * @return
     */
    private String getFieldValueWithAlignment(String value, DataField d) {
        StringBuilder token = new StringBuilder();
        int actualLength = value.length();
        if (d.getFieldLength() > actualLength) {
            if (d.isRightAligned()) {
                token.append(StringUtils.repeat(SPACE, d.getFieldLength() - actualLength)).append(value);
            } else {
                token.append(value).append(StringUtils.repeat(SPACE, d.getFieldLength() - actualLength));
            }
        } else {
            token.append(value);
        }
        return token.toString();
    }

}
