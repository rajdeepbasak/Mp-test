package com.ups.ttg.flight.acars.message.parser.vo;

import lombok.Data;

@Data
public class DataField implements Comparable<DataField> {
    private String fieldName;
    private String fieldLabel;
    private int fieldSequence;
    private int fieldPosition;
    private int fieldLength;
    private String format;
    private boolean optional = false;
    private boolean rightAligned = false;
    private boolean leftAligned = false;
    private String separatedBy;
    private String suffix;
    private boolean endOfLine;
    private String defaultCharacter;
    private String value;

    public int compareTo(DataField d) {
        return this.fieldSequence - d.getFieldSequence();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DataField other = (DataField) obj;
        if (fieldName == null) {
            if (other.fieldName != null)
                return false;
        } else if (!fieldName.equals(other.fieldName))
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((fieldName == null) ? 0 : fieldName.hashCode());
        return result;
    }
}
