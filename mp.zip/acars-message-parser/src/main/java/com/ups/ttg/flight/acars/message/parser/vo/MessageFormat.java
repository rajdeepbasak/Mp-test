package com.ups.ttg.flight.acars.message.parser.vo;

import java.util.List;

import lombok.Data;

@Data
public class MessageFormat {

    private String smiCode;
    private String messageType;
    private List<DataField> dataFieldList;
}
