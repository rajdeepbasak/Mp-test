package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageM3S implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String weatherStation;
    private String surfaceAnalysisSwitch;
    private String terminalForecastSwitch;
    private String notamsSwitch;
    private String windsAloftSwitch;
    private String sigmentSwitch;
    private String radarReportSwitch;
    private String wxrWatchSwitch;
    private String otherType;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
