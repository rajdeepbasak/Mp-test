package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class APUProcessTableParam {

    private String industrySteeringCommittee;
    private String aircraftRotationPerMinute;
    private String apuSwitch;
    private String apuRun;
    private String apuTimeinSeconds;
    private String apuValid;

}
