package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3K structure to store values comes in M3K messages
 */
@Data
public class MessageM3K implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String outEventTime;
    private String totalFuel;
    private String fuelAdded;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
