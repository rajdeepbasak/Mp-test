package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class MessageM4B implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String msgFlightNumber;
    private String captain1Id;
    private String firstOfficer1Id;
    private String secondOrReliefOfficerId;
    private String captain2Id;
    private String firstOfficer2Id;
    private String messageType;
    private String totalBlockHours;
    private String totalCrewHours;
    private String captain1Hours;
    private String firstOfficer1Hours;
    private String secondOrReliefOfficerHours;
    private String captain2Hours;
    private String firstOfficer2Hours;
    private String otherMessageText;

    @JsonIgnore
    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
