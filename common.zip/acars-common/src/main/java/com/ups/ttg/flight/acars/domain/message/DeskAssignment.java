/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class DeskAssignment {

    private String responseOfficeLocationCode;
    private String deskAssignmentName;

}
