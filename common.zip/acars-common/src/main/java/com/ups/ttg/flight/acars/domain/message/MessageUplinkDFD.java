package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageUplinkDFD implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String freeText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
