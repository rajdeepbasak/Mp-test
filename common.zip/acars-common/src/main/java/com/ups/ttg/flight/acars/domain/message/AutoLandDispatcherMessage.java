package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class AutoLandDispatcherMessage {
    
    private String freeText;
}

