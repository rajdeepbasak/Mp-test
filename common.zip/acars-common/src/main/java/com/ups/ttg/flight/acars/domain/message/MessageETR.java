package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep ETR structure to store values comes in ETR messages
 */
@Data
public class MessageETR implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
