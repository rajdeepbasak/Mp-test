package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageDownlinkDFD implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String freeText;

    private String apuStart;
    private String apuStartP3;
    private String apuStartP5;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
