package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M4H structure to store values comes in M4H messages
 */
@Data
public class MessageM4H implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
