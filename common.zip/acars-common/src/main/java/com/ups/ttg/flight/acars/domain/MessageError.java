package com.ups.ttg.flight.acars.domain;

import lombok.Data;

@Data
public class MessageError {
    private String code;
    private String description;

    private int position;
    private int length;
    private String field;

    public MessageError() {

    }

    public MessageError(ValidationErrorMessage errorEnum) {
        this.code = errorEnum.getErrorNumber();
        this.description = errorEnum.getErrorMessage();
    }

    public MessageError(ValidationErrorMessage errorEnum, String field) {
        this.code = errorEnum.getErrorNumber();
        this.description = errorEnum.getErrorMessage();
        this.field = field;
    }

    public MessageError(ValidationErrorMessage errorEnum, int position, int length) {
        this.code = errorEnum.getErrorNumber();
        this.description = errorEnum.getErrorMessage();
        this.position = position;
        this.length = length;
    }

    public MessageError(String errorNumber, String errorMessage, int position, int length) {
        super();
        this.code = errorNumber;
        this.description = errorMessage;
        this.position = position;
        this.length = length;
    }

    public MessageError(String errorNumber, String errorMessage, int position, int length, String field) {
        super();
        this.code = errorNumber;
        this.description = errorMessage;
        this.position = position;
        this.length = length;
        this.field = field;
    }

    public MessageError(ValidationErrorMessage errorEnum, int position, int length, String field) {
        this.code = errorEnum.getErrorNumber();
        this.description = errorEnum.getErrorMessage();
        this.position = position;
        this.length = length;
        this.field = field;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        MessageError other = (MessageError) obj;
        if (code == null) {
            if (other.code != null)
                return false;
        } else if (!code.equals(other.code))
            return false;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + ((field == null) ? 0 : field.hashCode());
        result = prime * result + length;
        result = prime * result + position;
        return result;
    }

}
