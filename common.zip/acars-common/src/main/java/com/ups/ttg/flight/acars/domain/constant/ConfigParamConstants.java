package com.ups.ttg.flight.acars.domain.constant;

public final class ConfigParamConstants {

    // Config param KEY
    public static final String CREATE_UPLK = "CreateUplink";
    public static final String CREATE_UPLK_FOR = "CreateUplinkFor";
    public static final String CREATE_UPLK_FOR_VALUE_M37_CERTIFICATION = "M37StopReminder";
    public static final String WXR_STATUS = "WXRStatus";
    public static final String WITHIN_16_HOURS = "isWithin16Hours";
    public static final String APU_PROCESS = "APUProcess";
    public static final String AIRCRAFT_TYPE = "aircraftType";
    public static final String AIRCRAFT_MODEL_NUMBER = "aircraftModelNumber";
    public static final String ROUTE_TO = "RouteTo";
    public static final String MU_VERSION = "muVersion";
    public static final String AIRCRAFT_VERSION_NUMBER = "aircraftVersionNumber";
    public static final String SKIP_AC_DB_UPADTE = "skipAcDbUpdate";
    public static final String M41_FOR_REQ_STATUS = "m41ForReqStatus";
    public static final String M41_FORMAT_TO_USE = "m41FormatToUse";

    public static final String AIRCRAFT_MODEL_747="747";
    
    public static final String IS_FROM_RAT="isFromRAT";
    public static final String IS_DFD_UPLINK="isDfdUplink";
    
    // Config param VALUE
    public static final String SMI_M37 = "M37";
    public static final String SMI_M39 = "M39";
    public static final String SMI_M3X = "M3X";
    public static final String SMI_M40 = "M40";
    public static final String SMI_M41 = "M41";
    public static final String SMI_M42 = "M42";
    public static final String SMI_M46 = "M46";
    public static final String SMI_WXD = "WXD";
    public static final String SMI_M4C = "M4C";
    public static final String SMI_AID0000051 = "AID0000051"; // Dry Ice
    public static final String SMI_AID0000053 = "AID0000053"; // Drug

    public static final String TRUE = "true";
    public static final String FALSE = "false";
    public static final String WXR_STATUS_I = "I";

    public static final String APU_PROCESS_START = "APUProcessStart";
    public static final String APU_PROCESS_STOP = "APUProcessStop";
    public static final String APU_PROCESS_RESPONSE = "APUResponse ";

    public static final String PDC = "PDC";
    public static final String NOT_APU_PROCESS = "NotAPUProcess ";
    public static final String FIRST_REPORT_FLAG = "FirstReportFlag";
    public static final String LOAD_BALANCE = "LoadBalance";
    public static final String ETOPS = "ETOPS";

    public static final String AIRCOM = "AIRCOM";

    public static final String DEST_PRINTER = "PRS35809";
    public static final String DEST_NETLINE = "ZSDFAMC1";
    public static final String DEST_SDSS = "ZSDFAMC2";
    public static final String DEST_OPSYS = "ZSDFSYS2";
    public static final String DEST_UPLK_TO_AC = "SDFAD5X";

    public static final String ACK_REQUIREMENT_KEY = "ackRequired";
    public static final String CHIME_REQUIREMENT_KEY = "chimeRequired";
    public static final String MSG_ORIGIN_ADDRESS_KEY = "msgOriginAddress";
    public static final String FREE_TEXT_KEY = "freeText";

    public static final String ACK_REQUIREMENT_VALUE = "N";
    public static final String CHIME_REQUIREMENT_VALUE = "N";
    public static final String MSG_ORIGIN_ADDRESS_SDFXY5X = "SDFXY5X";
    public static final String MSG_ORIGIN_ADDRESS_FOR_M37_M40 = "SDFXY5X";
    public static final String M37_FREE_TEXT_FOR_M39 = "ESTIMATED DELAY EXCEEDS\r\nOPERATIONAL LIMITS.\r\nCONTACT YOUR DISPATCHER\r\nASAP.";
    public static final String M37_FREE_TEXT_FOR_M42 = "Flight information in the M42 does not match with Flight information in M41. Contact Dispatcher";
    public static final String M37_FREE_TEXT_FOR_M40 = "DO NOT DEPART.\r\nCONTACT FLIGHT CONTROL.\r\nPOSSIBLE TAIL # / OFP DISCREPANCY.\r\nACK/REJ WITH FLT #.";

    public static final String IS_M3B_ON = "IS_M3B_ON";
    public static final String IS_M3I_ON = "IS_M3I_ON";
    public static final String IS_M31_ON = "IS_M31_ON";
    public static final String FLAG_Y = "Y";
    public static final String FLAG_N = "N";
    public static final String CHAR_C = "C";
    public static final String NO_OF_ACM = "NO_OF_ACM";
    public static final String IS_FLIGHT_ON = "IS_FLIGHT_ON";
    public static final String AIRCRAFT_MODEL = "AIRCRAFT_MODEL";

    public static final String OTHER_THAN_C_OR_SPACE = "Not C or Space";

    private ConfigParamConstants() {
        // restrict instantiation
    }
}
