package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageM3X implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;
    private String accessIdentifier;
    private String accessStatus;
    private String atcFlightIdIdentifier;
    private String atcFlightId;
    private String commFlightIdIdentifier;
    private String commFlightId;
    private String oilPressureOverrideIdentifier;
    private String overrideStatus;
    private String posWxrMsgActivityIdentifier;
    private String posWxrMsgStatus;
    private String posWxrMsgIntervalIdentifier;
    private String posWxrMsgInterval;
    private String takeOffStatusReportMsgActivityIdentifier;
    private String takeOffStatusReportStatus;
    private String groundSpeedLimitIdentifier;
    private String groundSpeedLimit;
    private String depDelayAdvisoryTimerLimitIdentifier;
    private String depDelayAdvisoryTimerLimit;
    private String faultReqActivityIdentifier;
    private String faultReportStatus;
    private String faultReqIntervalIdentifier;
    private String faultReportTimer;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
