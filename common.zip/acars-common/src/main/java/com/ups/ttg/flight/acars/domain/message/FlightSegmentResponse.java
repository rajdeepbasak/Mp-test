/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import java.util.List;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class FlightSegmentResponse {

    private FlightSegmentKey flightSegmentKey;
    private String aircraftOwnerCode;
    private String aircraftRegistrationNumber;
    private String aircraftType;
    private String destinationIataAirportCode;
    private String diversionIataAirportCode;
    private String originIcaoAirportCode;
    private String destinationIcaoAirportCode;
    private String diversionIcaoAirportCode;
    private String scheduledDepartureTimestamp;
    private String scheduledArrivalTimestamp;
    private String estimatedDepartureTimestamp;
    private String estimatedArrivalTimestamp;
    private String actualDepartureTimestamp;
    private String actualOutTimestamp;
    private String actualOffTimestamp;
    private String actualOnTimestamp;
    private String actualInTimestamp;
    private String actualArrivalTimestamp;
    private String nextInformationTimestamp;
    private String movementStatusCode;
    private String planCommentText;
    private String informationSourceTypeCode;
    private String recordUpdateTimestamp;
    private ParkingPosition parkingPosition;
    private DeskAssignment deskAssignment;
    private List<CrewMemberCrewAssignments> crewmemberCrewAssignments;
    private List<Delays> delays;

}
