/**
 * 
 */
package com.ups.ttg.flight.acars.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class MessageWrapper {

    private String smiNumber;
    private String flightNumber;
    private String origin;
    private String destination;
    private String flightDate;
    private String aircraftRegistrationNumber;
    private String messageAsJson;
    private RawMessage rawMessage = new RawMessage();
    private ActiveFlightDetails activeFlightDetails;
    private String messageType;

    private List<MessageError> errors = new ArrayList<>();
    private Map<String, String> configParams = new HashMap<>();
    @JsonIgnore
    private Map<String, String> parseError = new HashMap<>();

}
