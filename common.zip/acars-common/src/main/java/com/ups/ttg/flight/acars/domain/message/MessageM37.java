package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M37 structure to store values comes in M37 messages
 */
@Data
public class MessageM37 implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String ackRequired;
    private String chimeRequired;
    private String msgOrigineAddress;
    private String flightNumber;
    private String flightDate;
    private String originStationCode;
    private String destinationStationCode;
    private String freeText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
