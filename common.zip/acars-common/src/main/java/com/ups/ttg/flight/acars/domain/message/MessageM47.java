package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageM47 implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String messageDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String oooiState;
    private String updateTimePeriod;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
