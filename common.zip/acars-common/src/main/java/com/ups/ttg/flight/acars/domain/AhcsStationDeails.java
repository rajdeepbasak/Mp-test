package com.ups.ttg.flight.acars.domain;

import lombok.Data;

@Data
public class AhcsStationDeails {

    private String ahcsStationCode;

    public AhcsStationDeails(String ahcsStationCode) {
        this.ahcsStationCode = ahcsStationCode;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AhcsStationDeails other = (AhcsStationDeails) obj;
        if (ahcsStationCode == null) {
            if (other.ahcsStationCode != null)
                return false;
        } else if (!ahcsStationCode.equals(other.ahcsStationCode))
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((ahcsStationCode == null) ? 0 : ahcsStationCode.hashCode());
        return result;
    }
}
