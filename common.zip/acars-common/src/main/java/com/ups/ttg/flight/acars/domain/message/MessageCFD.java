package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageCFD implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String userCode;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
