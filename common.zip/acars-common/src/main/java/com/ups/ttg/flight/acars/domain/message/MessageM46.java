package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageM46 implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String engine1StartTime;
    private String engine2StartTime;
    private String engine3StartTime;
    private String engine4StartTime;
    private String lastCargoDoorCloseTime;
    private String crewDoorCloseTime;
    private String frontBellyDoorCloseTime;
    private String rearBellyDoorCloseTime;
    private String outEventTime;
    private String dfdauStatus;
    private String ltn92Present;
    private String oooiStatus;
    private String modifyParamIdentifier;
    private String accessStatus;
    private String atcFlightIDIdentifier;
    private String atcFlightID;
    private String comFlightIDIdentifier;
    private String comFlightID;
    private String userFlightIDIdentifier;
    private String userFlightID;
    private String preKeyingValueIdentifier;
    private String preKeyingValue;
    private String trackerMessageIdentifier;
    private String trackerMessageStatus;
    private String trackerIntervalIdentifier;
    private String trackerInterval;
    private String oilPressureOverrideIdentifier;
    private String overrideStatus;
    private String posWxrMessageActvtyIdentifier;
    private String pos_wxrMessageStatus;
    private String posWxrMessageIntervalIdentifier;
    private String pos_wxrMessageInterVal;
    private String takeoffStatusReportIdentifier;
    private String takeoffStatusReportStatus;
    private String ascentDescentReportActvtyIdentifier;
    private String ascent_descentReportStatus;
    private String groundSpeedLimitIdentifier;
    private String groundSpeedLimit;
    private String groundSpeedTimerIdentifier;
    private String groundSpeedTimerVal;
    private String region1Identifier;
    private String region1Name;
    private String region1Frequency;
    private String region2Identifier;
    private String region2Name;
    private String region2Frequency;
    private String region3Identifier;
    private String region3Name;
    private String region3Frequency;
    private String region4Identifier;
    private String region4Name;
    private String region4Frequency;
    private String dep_delayAdvisoryTimerLimitIdentifier;
    private String dep_delayAdvisoryTimerLimit;
    private String faultReqActvtyIdentifier;
    private String faultReqStatus;
    private String faultReqIntervalIdentifier;
    private String faultReportTimer;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
