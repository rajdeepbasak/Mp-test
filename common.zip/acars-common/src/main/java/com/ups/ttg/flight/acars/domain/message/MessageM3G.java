package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageM3G implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String logPageNumber;
    private String logItemNumber;

    // 1 Character for '/'
    private String mxCode;
    private String freeText;
    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
