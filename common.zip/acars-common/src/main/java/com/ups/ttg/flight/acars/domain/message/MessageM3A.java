package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3A structure to store values comes in M3A messages
 */
@Data
public class MessageM3A implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String messageSMI;
    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String outEventTime;
    private String estimatedOffTime;
    private String estimatedEta;
    private String delayCode;
    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
