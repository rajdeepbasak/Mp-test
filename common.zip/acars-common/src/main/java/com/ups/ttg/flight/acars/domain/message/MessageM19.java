package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageM19 implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
