/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class Delays {

    private String delayReasonCode;
    private String subDelayCode;
    private String delayReasonText;
    private String flightDelaySupplementalInformationText;
    private DelayTime delayTime;

}
