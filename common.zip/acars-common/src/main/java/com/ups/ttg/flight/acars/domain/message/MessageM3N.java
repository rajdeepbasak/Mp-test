package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3N structure to store values comes in M3N messages
 */
@Data
public class MessageM3N implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;
    // Fields for M3N Error message
    private String freeText;

    // Fields for M3N Success message
    private String flightNumber;
    private String originStation;
    private String destinationStation;
    private String smi;
    private String flightDate;
    private String atcClearanceHeaderLine;

    // Start: Fields for preferential M3N Success Message
    private String preferentialHeaderLine2;
    private String preferentialHeaderLine3;
    private String preferentialHeaderLine4;
    private String preferentialRouteInformation;
    private String preferentialHeaderLine5;
    private String preferentialHeaderLine6;
    // End: Fields for preferential M3N Success Message

    private String altitudeTextDescription;
    private String departureFrequencyDescription;
    private String sqwuakCodeLabel;
    private String sqwuakCode;
    private String expectedDepartureClearanceTimeLabel;
    private String expectedDepartureClearanceTime;
    private String successMessageFreeText;
    private String filedFlightPlanHeader;
    private String filedRouteInformation;
    private String proposedDepartureEstimatedTimeLabel;
    private String proposedDepartureEstimatedTime;
    private String aircraftAltitudeLabel;
    private String aircraftAltitude;
    private String equipmentCodeLabel;
    private String equipmentCode;
    private String endOfMessageText;

    // Fields for non-preferential M3N Success message
    private String nonPreferentialHeader1;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
