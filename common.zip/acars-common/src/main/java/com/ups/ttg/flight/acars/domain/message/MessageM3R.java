package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageM3R implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String eta;
    private String cannedMessageCode;
    private String otherMessageText;
    private String freeText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
