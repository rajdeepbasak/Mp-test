package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M041 structure to store values comes in M041 messages
 */
@Data
public class Message041 implements AcarsMessage {

    private String destinationAddress;
    private String originAddress;
    private String dateOfCreation;
    private String smi;
    private String flightDetailIndicator;
    private String tailNumber;
    private String m40TimeStamp;
    private String errorCode;
    private String errorDescription;
    private String m41MessageIndicator;
    private String acarsVersion;
    private String errorIndicator;
    private String smiCode;
    private String flightNumber;
    private String flightDate;
    private String flightOrigin;
    private String flightDestination;
    private String flightSchedDepartureDate;
    private String flightSchedDepartureTime;
    private String flightSchedArrivalTime;
    private String enroutIndicator;
    private String flightEnrouteTime;
    private String crewDataIndicator;
    private String flightCaptainId;
    private String firstOfficerId;
    private String flightEngineerId;
    private String releifOfficerId;
    private String reserveCaptainId;
    private String reserveFirstOfficerId;
    private String taxiTimeIndicator;
    private String taxiOutTime;
    private String taxiInTime;

    @Override
    public MessageHeader getHeader() {
        return null;
    }

}
