/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class MessageM42 implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String aocApplID;
    private String firstReportFlag;
    private String flightDate;
    private String messageTime;
    private String msgFlightNumber;
    private String flightSuffix;
    private String scheduledDate;
    private String originationStation;
    private String destinationStation;
    private String totalFuel;
    private String takeoffRunway;
    private String captain1Id;
    private String firstOfficer1Id;
    private String secondOrReliefOfficerId;
    private String captain2Id;
    private String firstOfficer2Id;
    private String isManualInitialization;
    private String otherMessageText;

    @JsonIgnore
    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
