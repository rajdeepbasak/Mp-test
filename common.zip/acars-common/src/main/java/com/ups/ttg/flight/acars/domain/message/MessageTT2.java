package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class MessageTT2 implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String freeText;

    @JsonIgnore
    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
