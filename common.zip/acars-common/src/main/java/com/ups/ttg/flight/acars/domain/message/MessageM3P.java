package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3P structure to store values comes in M3P messages
 */
@Data
public class MessageM3P implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String rampAssignment;
    private String rampFrequency;
    private String freeText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
