/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class DelayTime {

    private String standardDays;
    private String standardHours;
    private String standardMinutes;
    private String standardSeconds;
    private String millis;

}
