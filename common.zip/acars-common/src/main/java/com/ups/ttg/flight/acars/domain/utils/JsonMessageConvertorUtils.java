package com.ups.ttg.flight.acars.domain.utils;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonMessageConvertorUtils<T> {

    /**
     * @param jsonMessage
     * @return MessageWrapper This method will convert json String to object
     * @throws IOException
     * @throws JsonMappingException
     * @throws JsonParseException
     */
    public T jsonToObject(String jsonMessage, Class<T> classType) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        T messageWrapper = null;
        messageWrapper = mapper.readValue(jsonMessage, classType);
        return messageWrapper;
    }

    /**
     * @param jsonMessage
     * @return MessageWrapper This method will convert json String to object
     * @throws IOException
     * @throws JsonMappingException
     * @throws JsonParseException
     */
    public String objectToJson(T object) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(object);
    }

}
