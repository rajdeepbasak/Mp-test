/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class PDCMessage implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String smi;
    private String atcSequenceNumber;
    private String flightNumber;
    private String atcSquawkCode;
    private String originationStation;
    private String aircraftEquipmentCode;
    private String proposedDepartureTime;
    private String msgSeqNumber;
    private String aircraftAltitude;
    private String flightPlanRouteText1;
    private String flightPlanRouteText2;
    private String flightPlanRouteText3;
    private String estimatedDepartureClearanceTime;
    private String revisionNumber;
    private String departureFrequencyDescription;
    private String altitudeDescription;
    private String freeTextLine3;
    private String freeTextLine4;
    private String freeTextLine5;
    private String freeTextLine6;
    private String freeTextLine7;
    @JsonIgnore
    private String otherMessageText;

    @JsonIgnore
    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }
}
