package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class MessageAPUStop implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String apuStopDFDType;
    private String apuStopFlightNumber;
    private String apuStopQuestion;
    private String apuTailNumber;
    private String apuStopMonth;
    private String apuStopDate;
    private String apuStopTimeHrs;
    private String apuStopTimeMin;
    private String apuStopTimeSec;
    private String apuStopTime;
    private String apuStopLatitude;
    private String apuStopLongitude;
    private String apuStopFlightMode;
    private String freeText;

    @JsonIgnore
    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
