package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M36 structure to store values comes in M36 messages
 */
@Data
public class MessageM36 implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String msgOrigineAddress;
    private String artrNumber;
    private String artrText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
