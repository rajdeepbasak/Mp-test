package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class PlwHistory {

    private String updateTimestamp;

    private String fuel;

    private String additionalCrewMembers;

    private String loadManifestStatus;

    private String loadManifestTime1;

    private String takeoffRunway;

    private String originStation;

    private String destinationStation;

    private String groundStation;
}
