package com.ups.ttg.flight.acars.domain;

import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class RawMessage {
    public static final String STRING_TYPE = "String";

    private String contentType;
    private String messageContent;

    public RawMessage(String contentType, String messageContent) {
        super();
        this.contentType = contentType;
        this.messageContent = Base64.getEncoder().encodeToString(messageContent.getBytes(UTF_8));
    }

    public RawMessage() {
        super();
    }

    /**
     * @return the contentType
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * @param contentType
     *            the contentType to set
     */
    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    /**
     * @return the messageContent
     * @throws UnsupportedEncodingException
     */
    public String getMessageContent() {
        return messageContent;
    }

    /**
     * @param messageContent
     *            the messageContent to set
     * @throws UnsupportedEncodingException
     */
    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

    /**
     * Method to decode message
     * 
     * @param messageContent
     */
    @JsonIgnore
    public String getDecodeMessage() {
        return new String(Base64.getDecoder().decode(messageContent), UTF_8);
    }

}
