package com.ups.ttg.flight.acars.domain.utils;

import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.StringUtils;

public class ZonedDateTimeUtils {

  public static final String MONTH_IN_YEAR = "MM";
  public static final String DAY_IN_MONTH = "dd";
  public static final String HOUR_IN_DAY = "HH";
  public static final String MINUTES = "mm";
  public static final String MONTH = "MMM";
  public static final String YEAR_IN_TWO_CHAR = "YY";
  public static final String DATE_FORMAT = "MM-dd-yyyy";

  /**
   * This Method converts utc Time String to Zoned DateTime
   * 
   * @param String
   *          utcTimeString
   * @return ZonedDateTime
   */
  public static ZonedDateTime stringToZdt(String utcTimeString) {
    return ZonedDateTime.parse(utcTimeString);
  }

  /**
   * This Method converts ZonedDateTime to a date in MMdd Format
   * 
   * @param ZonedDateTime
   *          zdt
   * @return String
   */
  public static String getDateAsMMDDFromZdt(ZonedDateTime zdt) {
    return zdt.format(DateTimeFormatter.ofPattern(MONTH_IN_YEAR))
        + zdt.format(DateTimeFormatter.ofPattern(DAY_IN_MONTH));
  }

  /**
   * This Method converts ZonedDateTime to a date in MM-dd-YYYY Format
   * 
   * @param ZonedDateTime
   * @return String
   */
  public static String getDateAsMMDDYYYYFromZdt(ZonedDateTime zdt) {
    return zdt.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
  }

  /**
   * This Method converts ZonedDateTime String to a date in MM-dd-YYYY Format
   * 
   * @param ZonedDateTime
   * @return String
   */
  public static String getDateAsMMDDYYYYFromZdt(String zdtString) {
    ZonedDateTime zdt = stringToZdt(zdtString);
    return zdt.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
  }

  /**
   * This Method converts ZonedDateTime to a Date in dd Format
   * 
   * @param ZonedDateTime
   *          zdt
   * @return String
   */
  public static String getDateAsDDFromZdt(ZonedDateTime zdt) {
    return (zdt.format(DateTimeFormatter.ofPattern(DAY_IN_MONTH)));
  }

  /**
   * This Method converts ZonedDateTime to a Time in HHmm Format
   * 
   * @param ZonedDateTime
   *          zdt
   * @return String
   */
  public static String getTimeAsHHMMFromZdt(ZonedDateTime zdt) {
    return (zdt.format(DateTimeFormatter.ofPattern(HOUR_IN_DAY)) + zdt.format(DateTimeFormatter.ofPattern(MINUTES)));
  }

  /**
   * This Method converts ZonedDateTime to a Month in MMM Format
   * 
   * @param ZonedDateTime
   *          zdt
   * @return String
   */
  public static String getMonthAsMMMFromZdt(ZonedDateTime zdt) {
    return (zdt.format(DateTimeFormatter.ofPattern(MONTH)));
  }

  /**
   * This Method converts ZonedDateTime to a Year in yy Format
   * 
   * @param ZonedDateTime
   *          zdt
   * @return String
   */
  public static String getYearAsYYFromZdt(ZonedDateTime zdt) {
    return (zdt.format(DateTimeFormatter.ofPattern(YEAR_IN_TWO_CHAR)));
  }

  /**
   * This Method creates ZonedDateTime from Date dd and Time HHmm
   * 
   * @param String
   *          dayOfMonth
   * @param String
   *          timeHHMM
   * @return ZonedDateTime
   */
  public static ZonedDateTime getZdtFromDayAndTime(String dayOfMonth, String timeHHMM) {
    ZonedDateTime zdt = ZonedDateTime.now(ZoneOffset.UTC);
    zdt = ZonedDateTime.of(zdt.getYear(), zdt.getMonthValue(), Integer.valueOf(dayOfMonth),
        Integer.valueOf(StringUtils.substring(timeHHMM, 0, 2)), Integer.valueOf(StringUtils.substring(timeHHMM, 2)),
        zdt.getSecond(), zdt.getNano(), ZoneOffset.UTC);
    return (zdt.compareTo(ZonedDateTime.now(ZoneOffset.UTC)) > 0 ? zdt.minusMonths(1) : zdt);
  }

  /**
   * Gets Date difference zdt2-zdt1 in minutes
   * 
   * @param zdt1
   * @param zdt2
   * @return Long
   */
  public static Long getDateDifferenceInMinutes(ZonedDateTime zdt1, ZonedDateTime zdt2) {
    return (Duration.between(zdt1, zdt2).toMinutes());
  }

  /**
   * Accepts a string date in (MM-dd-yyyy) format and returns the Day of month
   * value
   * 
   * @param dateString
   * @return
   */
  public static String getDayOfMonthFromDateString(String dateString) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT).withZone(ZoneOffset.UTC);
    LocalDate date = LocalDate.parse(dateString, formatter);
    return Integer.toString(date.getDayOfMonth());
  }

}
