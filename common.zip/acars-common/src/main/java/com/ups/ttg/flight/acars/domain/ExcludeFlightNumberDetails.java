/*
Â *Â <p>
Â * The use, disclosure, reproduction, modification, transfer, or transmittal of this work for any purpose in any form or by
Â * any means without the written permission of United Parcel Service is strictly prohibited.Confidential, Unpublished Property
Â * of United Parcel Service. Use and Distribution Limited Solely to Authorized Personnel.
Â *Â <p>
Â * Copyright 2017 United Parcel Service of America, Inc. All Rights Reserved.
Â */
package com.ups.ttg.flight.acars.domain;

import lombok.Data;

/**
 * This is POJO class for ExcludeFlightNumberDetails
 * 
 *
 * 
 */
@Data
public class ExcludeFlightNumberDetails extends ReferenceWrapper {

    private String flightNumber;

    public ExcludeFlightNumberDetails(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public ExcludeFlightNumberDetails() {
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ExcludeFlightNumberDetails other = (ExcludeFlightNumberDetails) obj;
        if (flightNumber == null) {
            if (other.flightNumber != null)
                return false;
        } else if (!flightNumber.equals(other.flightNumber))
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((flightNumber == null) ? 0 : flightNumber.hashCode());
        return result;
    }

}
