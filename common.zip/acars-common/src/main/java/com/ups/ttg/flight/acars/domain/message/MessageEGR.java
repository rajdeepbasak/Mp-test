/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class MessageEGR implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String freeText;

    @JsonIgnore
    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
