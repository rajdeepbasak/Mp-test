/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class MessageM40 implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;
    private String aocAppID;
    private String flightDate;
    private String messageTime;
    private String iduVersionNumber;
    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
