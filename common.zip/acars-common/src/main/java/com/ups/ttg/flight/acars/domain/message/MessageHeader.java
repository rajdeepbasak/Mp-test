/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

/**
 * @author KUNAL
 *
 */
public interface MessageHeader {

}
