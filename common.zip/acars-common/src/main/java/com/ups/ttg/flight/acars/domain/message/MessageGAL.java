package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageGAL implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;
    private String flightSuffix;
    private String compassFlightDate;
    private String originationStation;
    private String destinationStation;
    private String freeText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
