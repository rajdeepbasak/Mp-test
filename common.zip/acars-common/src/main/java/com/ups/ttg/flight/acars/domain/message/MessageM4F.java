package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M4F structure to store values comes in M4F messages
 */
@Data
public class MessageM4F implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
