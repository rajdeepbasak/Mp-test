package com.ups.ttg.flight.acars.domain.message;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class MessageAPUStart implements AcarsMessage, MessageHeader {
    private AcarsMessageHeader acarsMessageHeader;

    private String apuStartHeader;
    private String aircraftIdentifierLabel;
    private String msgAircraftRegistrationNumber;
    private String msgFlightNumber;
    private String apuStartDate;
    private String apuStartDateMonth;
    private String apuStartTimeHrs;
    private String apuStartTimeMin;
    private String totalAirTemperature;
    private String staticAirTemperature;
    private String altitude;
    private String machine;
    private String grossWeight;
    private String mode;
    private String departureStation;
    private String destinationStation;
    private String version;
    private String tableHeader;
    private List<APUStartTableParam> apuStartTableParam;
    @JsonIgnore
    private String otherMessageText;

    @JsonIgnore
    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
