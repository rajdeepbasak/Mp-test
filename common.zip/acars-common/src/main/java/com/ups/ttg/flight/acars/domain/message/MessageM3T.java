package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3T structure to store values comes in M3T messages
 */
@Data
public class MessageM3T implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String stationID;
    private String displayID;
    private String freeText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
