/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class MessageREJ implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
