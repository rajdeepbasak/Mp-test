package com.ups.ttg.flight.acars.domain.message;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class MessagePLW implements AcarsMessage, MessageHeader {

    @JsonIgnore
    private AcarsMessageHeader acarsMessageHeader;

    @JsonIgnore
    private String rawData;

    @JsonIgnore
    private String messageType;

    private String smiCode;

    private String smiSubCode;

    @JsonIgnore
    private String positionTotal;

    private String flightNumber;

    private String flightDate;

    private String origin;

    private String destination;

    private String aircraftRegistrationNumber;

    private String loadManifestTime;

    private String payloadWghtLBQty;

    private String payloadWghtUnitOfMeasure;

    private String bowQty;

    private String bowUnitOfMeasure;

    private String[] fuelWghtLBQty;

    private String[] cgWghtQty;

    private String[] fobQty;

    private String[] takeOffWghtCgQty;

    private String[] takeOffWghtLBQty;

    private String[] crewMemberStbTrmQty;

    private String[] crewMemberStbQty;

    private String[] crewMemberStbTrmQty15;

    private String[] crewMemberStbQty15;

    private String[] crewMemberStbTrmQty20;

    private String[] crewMemberStbQty20;

    private String createTimestamp;

    private String updateTimestamp;

    @JsonIgnore
    private String zeroFuelWeightCenterOfGravity;

    @JsonIgnore
    private String fuelTakeoffWeight;

    @JsonIgnore
    private String stabilizerTrimValues;

    private String fuel;

    private String additionalCrewMembers;

    private String loadManifestStatus;

    private String takeoffRunway;

    private String originStation;

    private String destinationStation;

    private String groundStation;
    
    private String docType;

    private List<PlwHistory> history;

    @JsonIgnore
    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }
}