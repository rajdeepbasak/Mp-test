package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class MessagePOS implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String latitude;
    private String longitude;
    private String altitude;
    private String windDir;
    private String mach;
    private String sat;
    private String fob;

    @JsonIgnore
    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
