/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class MessageM44 implements AcarsMessage {

    private AcarsMessageHeader acarsMessageHeader;
    private String apGlFlag;
    private String numberOfACM;
    private String totalFuel;
    private String takeoffRunway;
    private String altimeter;
    private String oat;
    private String takeoffGrossWeight;
    private String sequenceNumber;
    private String freeText;
    private String flightDate;
    private String originStation;
    private String destinationStation;

    private String version;

    @JsonIgnore
    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
