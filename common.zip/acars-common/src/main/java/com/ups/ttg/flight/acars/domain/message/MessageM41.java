/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class MessageM41 implements AcarsMessage {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightId;
    private String scheduledDepDate;
    private String originationStation;
    private String destinationStation;
    private String scheduledDepTime;
    private String estTimeEnroute;
    private String scheduledDepTaxi;
    private String scheduledArrTaxi;
    private String takeoffRunway;
    private String captain1Id;
    private String firstOfficer1Id;
    private String secondOrReliefOfficerId;
    private String captain2Id;
    private String firstOfficer2Id;
    private String acm1Id;
    private String acm2Id;
    private String acm3Id;
    private String acm4Id;
    private String acm5Id;
    private String acm6Id;
    private String acm7Id;
    private String acm8Id;
    private String acm9Id;
    private String acm10Id;
    private String scanArincNAmer;
    private String scanSitaEu;
    private String scanSitaAsia;
    private String scanJapan;
    private String scanSitaNAmer;
    private String scanArincEU;
    private String scanBrazil;
    private String scanChina;
    private String voxTuning;

    @JsonIgnore
    private String muVersion;
    @JsonIgnore
    private String reqZonedDateTime;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
