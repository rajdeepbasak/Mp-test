package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3D structure to store values comes in M3D messages
 */
@Data
public class MessageM3D implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String ias;
    private String mach;
    private String prsalt;
    private String ratOrtatText;
    private String ratOrtatValue;
    private String satText;
    private String satValue;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
