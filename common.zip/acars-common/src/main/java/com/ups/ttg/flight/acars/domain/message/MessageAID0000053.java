package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/**
 * @author Rajdeep M37 structure to store values comes in M37 messages
 */
@Data
public class MessageAID0000053 implements AcarsMessage, MessageHeader {
    @JsonIgnore
    private AcarsMessageHeader acarsMessageHeader;

    private String messageSeqNumber;
    private String messageId;
    private String messageTimestamp;
    private String destAddress;
    private String originAddress;
    private String aircraftRegNumber;
    private String carrier;
    private String flightNumberForMsg;
    private String flightOrigin;
    private String flightDestination;
    private String crewId;
    private String crewFirstName;
    private String crewLastName;
    private String freeText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
