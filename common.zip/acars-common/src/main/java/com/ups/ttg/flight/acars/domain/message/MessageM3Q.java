package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3Q structure to store values comes in M3Q messages
 */
@Data
public class MessageM3Q implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String outEventTime;
    private String inEventTime;
    private String deIceFlag;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
