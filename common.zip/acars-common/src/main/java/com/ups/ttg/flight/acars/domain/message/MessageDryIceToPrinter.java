package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class MessageDryIceToPrinter implements AcarsMessage, MessageHeader {
    @JsonIgnore
    private AcarsMessageHeader acarsMessageHeader;

    private String smi;
    private String priority;
    private String destinationAddress;
    private String originAddress;
    private String dryIcePrintInOut;
    private String dryIceIndicator;
    private String flightNumber;
    private String flightDay;
    private String aircraftRegistrationNumber;
    private String flightOrigin;
    private String flightDestination;
    private String freeText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
