package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3B structure to store values comes in M3B messages
 */
@Data
public class MessageM3B implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;
    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String outEventTime;
    private String movemetDetectedTime;
    private String offEventTime;
    private String eta;
    private String destinationStation;
    private String totalFuelTakeOff;
    private String delayCode;
    private String otherDelayReason;
    private String freeText;

    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
