package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3N structure to store values comes in M3N messages
 */
@Data
public class MessageFML implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
