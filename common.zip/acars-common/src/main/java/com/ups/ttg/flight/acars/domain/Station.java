/*
Â *Â <p>
Â * The use, disclosure, reproduction, modification, transfer, or transmittal of this work for any purpose in any form or by
Â * any means without the written permission of United Parcel Service is strictly prohibited.Confidential, Unpublished Property
Â * of United Parcel Service. Use and Distribution Limited Solely to Authorized Personnel.
Â *Â <p>
Â * Copyright 2017 United Parcel Service of America, Inc. All Rights Reserved.
Â */
package com.ups.ttg.flight.acars.domain;

import lombok.Data;

/**
 * This is POJO class for Station
 * 
 *
 * 
 */
@Data
public class Station extends ReferenceWrapper {

    private String stationCode;
    private String stationShortCode;

    public Station(String stationShortCode) {
        this.stationShortCode = stationShortCode;
    }

    public Station() {
    }

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Station other = (Station) obj;
		if (stationShortCode == null) {
			if (other.stationShortCode != null)
				return false;
		} else if (!stationShortCode.equals(other.stationShortCode))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((stationShortCode == null) ? 0 : stationShortCode.hashCode());
		return result;
	}
    
    
    

    /*@Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Station other = (Station) obj;
        if (stationCode == null) {
            if (other.stationCode != null)
                return false;
        } else if (!stationCode.equals(other.stationCode))
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((stationCode == null) ? 0 : stationCode.hashCode());
        return result;
    }
*/
}
