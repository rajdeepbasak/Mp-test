package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M4N structure to store values comes in M4N messages
 */
@Data
public class MessageM4N implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
