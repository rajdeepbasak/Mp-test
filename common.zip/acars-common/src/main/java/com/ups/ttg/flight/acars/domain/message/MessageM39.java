package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageM39 implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String messageSMI;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String departureDay;
    private String estimatedOutTime;
    private String delayCode;
    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
