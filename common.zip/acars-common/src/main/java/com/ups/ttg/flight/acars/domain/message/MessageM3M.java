package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3M structure to store values comes in M3M messages
 */
@Data
public class MessageM3M implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
