/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class CrewMemberCrewAssignments {

    private String gemsNumber;
    private String personLastName;
    private String personMiddleInitialName;
    private String personFirstName;
    private String aircraftSeatTypeCode;

}
