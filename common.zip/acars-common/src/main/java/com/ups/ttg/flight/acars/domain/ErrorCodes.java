package com.ups.ttg.flight.acars.domain;

import lombok.Getter;

/**
 * This is an enum of the different Error Codes this service may encounter
 * 
 *
 */

public enum ErrorCodes {

    ERROR("There was a generic error processing in Reference Data Service");

    @Getter
    private String errorMessage;

    private ErrorCodes(String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
