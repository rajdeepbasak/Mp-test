/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class MessageM40Request {

    private String movementNumber;
    private String startMovementIdentificationDate;
    private String endMovementIdentificationDate;
    private String aircraftOwnerCode;
    private String aircraftRegistrationNumber;
    private String aircraftType;
    private String originIataAirportCode;
    private String destinationIataAirportCode;
    private String diversionIataAirportCode;
    private String originIcaoAirportCode;
    private String destinationIcaoAirportCode;
    private String diversionIcaoAirportCode;
    private String destinationOrDiversionIataAirportCode;
    private String startScheduledDepartureTimeRange;
    private String endScheduledDepartureTimeRange;
    private String startScheduledArrivalTimeRange;
    private String endScheduledArrivalTimeRange;
    private String startEstimatedDepartureTimeRange;
    private String endEstimatedDepartureTimeRange;
    private String startEstimatedArrivalTimeRange;
    private String endEstimatedArrivalTimeRange;
    private String startActualDepartureTimeRange;
    private String endActualDepartureTimeRange;
    private String startActualArrivalTimeRange;
    private String endActualArrivalTimeRange;
    private String startScheduledOrEstimatedDepartureTimeRange;
    private String endScheduledOrEstimatedDepartureTimeRange;
    private String startScheduledOrEstimatedArrivalTimeRange;
    private String endScheduledOrEstimatedArrivalTimeRange;
    private String movementStatusCode;
    private String movementSequenceKeyDistinguishingNumber;
    private String informationSourceTypeCode;
    private String recordUpdateTimestamp;
    private String flightPlanCommentText;
    private String limit;
    private String offset;

}
