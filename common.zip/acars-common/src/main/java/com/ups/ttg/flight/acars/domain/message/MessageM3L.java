package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3L structure to store values comes in M3L messages
 */
@Data
public class MessageM3L implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String messageFlightNumber;
    private String captainID;
    private String firstOfficerID;
    private String secondOfficerID;
    private String landingOfficerCode;
    private String landingCategory;
    private String takeoffRunway;
    private String landingRunway;
    private String runwayVisibleRange;
    private String runwayVisibleRangeSign;
    private String numberOfLandings;
    private String logPageNumber;
    private String takeoffGrossWeight;
    private String currentInFuel;
    private String previousInFuel;
    private String fuelAdded;
    private String currentOutFuel;
    private String currentOffFuel;
    private String maxPowerTakeoff;
    private String oilAddedEng1;
    private String oilAddedEng2;
    private String oilAddedEng3;
    private String oilAddedEng4;
    private String oilAddedAPU;
    private String apuTime;
    private String apuCycles;
    private String outEventTime;
    private String pushBackTime;
    private String offEventTime;
    private String onEventTime;
    private String inEventTime;
    private String isInvalidOOITime;
    private String doorOpenTime;
    private String takeOffOfficerCode;
    private String captain2ID;
    private String firstOfficer2ID;
    private String unsatReasonCode;
    private String otherUnsatReason;
    private String disconnetAltitude;
    private String totaldepartureDelay;
    private String departureDelayCode1;
    private String otherDepartureDelayReason1;
    private String departureDelayPeriod1;
    private String departureDelayCode2;
    private String otherDepartureDelayReason2;
    private String departureDelayPeriod2;
    private String departureDelayCode3;
    private String otherDepartureDelayReason3;
    private String departureDelayPeriod3;
    private String taxiDelayCode;
    private String otherTaxiDelayReason;
    private String taxiDelayPeriod;
    private String enrouteDelayCode;
    private String otherEnrouteDelayReason;
    private String enrouteDelayPeriod;
    private String arrivalTaxiDelayCode;
    private String otherArrivalTaxiDelayReason;
    private String arrivalTaxiDelayPeriod;
    private String freeText;
    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
