package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3C structure to store values comes in M3C messages
 */
@Data
public class MessageM3C implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String oriGinaldestinationStation;
    private String eta;
    private String destinationStation;
    private String diversionCode;
    private String otherdelayReason;
    private String freeText;
    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
