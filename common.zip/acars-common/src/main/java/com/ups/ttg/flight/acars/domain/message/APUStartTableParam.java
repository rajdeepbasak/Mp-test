package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class APUStartTableParam {

    private String apuStart;
    private String apuStartP1;
    private String apuStartP2;
    private String apuStartP3;
    private String apuStartP4;
    private String apuStartP5;

}
