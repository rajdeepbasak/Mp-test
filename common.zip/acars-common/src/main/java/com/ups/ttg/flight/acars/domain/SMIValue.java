package com.ups.ttg.flight.acars.domain;

import java.util.Optional;
import java.util.stream.Stream;

import lombok.Getter;

public enum SMIValue {
    // From AOCB
    AID0000051("AID0000051", true, false, false, false, false),
    AID0000053("AID0000053", true, false, false, false, false),

    // DFD("DFD", false, true, false, false, false),
    FML("FML", false, true, false, false, false),
    FMR("FMR", false, true, false, false, false),
    M36("M36", false, true, false, false, false),
    M37("M37", false, true, false, false, true),
    M3N("M3N", false, true, false, false, false),
    M3P("M3P", false, true, false, false, false),
    M3T("M3T", false, true, false, false, false),
    M3V("M3V", false, true, false, false, false),
    M3X("M3X", false, true, false, false, true),
    M41("M41", false, true, false, false, true),
    M44("M44", false, true, false, false, false),
    M4F("M4F", false, true, false, false, false),
    M4G("M4G", false, true, false, false, false),
    M4H("M4H", false, true, false, false, false),
    M4I("M4I", false, true, false, false, false),
    M4J("M4J", false, true, false, false, false),
    M4K("M4K", false, true, false, false, false),
    M4L("M4L", false, true, false, false, false),
    
    CLD("CLD", true, false, false, false, false),

    // DownLink SMIS
    CFD("CFD", true, false, false, true, false),
    CLA("CLA", true, false, false, true, false),
    CLK("CLK", true, false, true, true, false),
    DFD("DFD", true, false, false, true, false),
    DRY_ICE_TO_PRINTER("DryIceToPrinter", true, false, false, true, false),
    ETR("ETR", true, false, false, true, false),
    GAL("GAL", true, false, false, true, false),
    M19("M19", true, false, false, true, false),
    M30("M30", true, false, false, true, false),
    M31("M31", true, false, true, true, false),
    M32("M32", true, false, true, true, false),
    M33("M33", true, false, true, true, false),
    M34("M34", true, false, true, true, false),
    M35("M35", true, false, true, true, false),
    M39("M39", true, false, true, true, false),
    M3A("M3A", true, false, true, true, false),
    M3B("M3B", true, false, true, true, false),
    M3C("M3C", true, false, true, true, false),
    M3D("M3D", true, false, false, true, false),
    M3E("M3E", true, false, true, true, false),
    M3F("M3F", true, false, true, true, false),
    M3G("M3G", true, false, true, true, false),
    M3I("M3I", true, false, true, true, false),
    M3J("M3J", true, false, true, true, false),
    M3K("M3K", true, false, true, true, false),
    M3L("M3L", true, false, true, true, false),
    M3M("M3M", true, false, true, true, false),
    M3Q("M3Q", true, false, true, true, false),
    M3R("M3R", true, false, true, true, false),
    M3S("M3S", true, false, true, true, false),
    M3U("M3U", true, false, true, true, false),
    M3Y("M3Y", true, false, false, true, false),
    M40("M40", true, false, false, true, false),
    M42("M42", true, false, true, true, false),
    M43("M43", true, false, true, true, false),
    M45("M45", true, false, true, true, false),
    M46("M46", true, false, true, true, false),
    M47("M47", true, false, true, true, false),
    M48("M48", true, false, true, true, false),
    M49("M49", true, false, true, true, false),
    M4A("M4A", true, false, true, true, false),
    M4B("M4B", true, false, true, true, false),
    M4C("M4C", true, false, true, true, false),
    M4M("M4M", true, false, false, true, false),
    M4N("M4N", true, false, false, true, false),
    M4P("M4P", true, false, false, false, false),
    MAS("MAS", true, false, false, false, false),
    MED("MED", true, false, false, false, false),
    OAT("OAT", true, false, false, false, false),
    PBR("PBR", true, false, false, true, false),
    POS("POS", true, false, false, true, false),
    RAI("RAI", true, false, false, false, false),
    RCL("RCL", true, false, false, false, false),
    REJ("REJ", true, false, false, false, false),
    SVC("SVC", true, false, false, true, false),
    TIS("TIS", true, false, false, true, false),
    WXE("WXE", true, false, false, false, false),
    WXF("WXF", true, false, false, true, false),
    PDC("PDC", true, false, false, true, false),
    PLW("PLW", true, false, false, true, false),

    // TODO: update the flag for following SMI's
    CLX("CLX", false, false, false, false, false),
    M5D("M5D", false, false, false, false, false),
    M5L("M5L", false, false, false, false, false);

    @Getter
    private String value;
    @Getter
    private boolean downLinkSmi;
    @Getter
    private boolean uplinkSmi;
    @Getter
    private boolean updateState;
    @Getter
    private boolean routeToRAT;
    @Getter
    private boolean routeToUplink;

    private SMIValue(String value, boolean downLinkSmi, boolean uplinkSmi, boolean updateState, boolean routeToRAT,
            boolean routeToUplink) {
        this.value = value;
        this.downLinkSmi = downLinkSmi;
        this.uplinkSmi = uplinkSmi;
        this.updateState = updateState;
        this.routeToRAT = routeToRAT;
        this.routeToUplink = routeToUplink;
    }

    public static boolean isValidSMI(String smi) {
        return Stream.of(SMIValue.values()).filter(e -> e.getValue().equalsIgnoreCase(smi)).findFirst().isPresent();
    }

    /**
     * This method checks if a smi value is valid uplink or not
     * 
     * @param smi
     * @return
     */
    public static boolean isValidUplinkSMI(String smi) {
        return Stream.of(SMIValue.values()).filter(e -> e.isUplinkSmi() && e.getValue().equalsIgnoreCase(smi))
                .findFirst().isPresent();
    }

    /**
     * This method checks if a smi value is valid downlink or not
     * 
     * @param smi
     * @return
     */
    public static boolean isValidDownLinkSMI(String smi) {
        return Stream.of(SMIValue.values()).filter(e -> e.isDownLinkSmi() && e.getValue().equalsIgnoreCase(smi))
                .findFirst().isPresent();
    }

    /**
     * This method checks whether a smi needs to route to RAT
     * 
     * @param smi
     * @return
     */
    public static boolean isSmiRouteToRAT(String smi) {
        return Stream.of(SMIValue.values()).filter(e -> (e.getValue().equalsIgnoreCase(smi) && e.isRouteToRAT()))
                .findFirst().isPresent();
    }

    /**
     * This method checks whether a smi needs to route to Uplink queue
     * 
     * @param smi
     * @return
     */
    public static boolean isSmiRouteToUplink(String smi) {
        return Stream.of(SMIValue.values()).filter(e -> (e.getValue().equalsIgnoreCase(smi) && e.isRouteToUplink()))
                .findFirst().isPresent();
    }

    /**
     * This method checks whether a state of aircraft needs to be updated
     * 
     * @param smi
     * @return
     */
    public static boolean doesUpdateAircraftState(String smi) {
        return Stream.of(SMIValue.values()).filter(e -> e.getValue().equalsIgnoreCase(smi) && e.isUpdateState())
                .findFirst().isPresent();
    }
    
    public static String getMessageType(String smi) {
      Optional<SMIValue> smiValue = Stream.of(SMIValue.values()).filter(e -> e.getValue().equalsIgnoreCase(smi) && e.isUpdateState())
              .findFirst();
      String messageType = "";
      if(smiValue.isPresent()) {
        messageType = smiValue.map(SMIValue::isDownLinkSmi).orElse(false)?"Downlink":"Uplink";
      }
      return messageType;
  }
}
