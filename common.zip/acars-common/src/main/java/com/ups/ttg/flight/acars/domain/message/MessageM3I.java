package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M3I structure to store values comes in M3I messages
 */
@Data
public class MessageM3I implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String onEventTime;
    private String totalFuelTouchDown;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
