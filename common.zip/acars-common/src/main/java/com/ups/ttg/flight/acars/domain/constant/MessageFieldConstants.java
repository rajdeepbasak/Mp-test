/**
 * 
 */
package com.ups.ttg.flight.acars.domain.constant;

/**
 * @author 509133
 *
 */
public class MessageFieldConstants {
    private MessageFieldConstants() {
    } // Prevents instantiation

    public static final String LINE_SEPARATOR = "\r\n";
    // Header Fields

    public static final String ORIGIN_ADDRESS = "originAddress";
    public static final String SMI_CODE = "smi";
    public static final String FLIGHT_NUMBER_INDICATOR = "flightDetailIndicator";
    public static final String FLIGHT_NUMBER = "flightNumber";
    public static final String AIRCRAFT_REG_NUMBER_INDICATOR = "aircraftRegistrationNumberIndicator";
    public static final String AIRCRAFT_REG_NUMBER = "aircraftRegistrationNumber";
    public static final String DATALINK_INDICATOR = "dataLinkIndicator";
    public static final String SERVICE_PROVIDER_ID = "serviceProviderId";
    public static final String GROUND_STATION = "groundStation";
    public static final String MESSAGE_SEQ_NUMBER = "messageSequenceNumber";
    public static final String CURRENT_DATE = "currentDate";
    public static final String CURRENT_TIME = "currentTime";
    public static final String FLIGHT_SUFFIX = "flightSuffix";
    public static final String MESSAGE_TYPE = "messageType";

    // Message Fields - Arranged Alphabetically

    public static final String ACARS_MESSAGE_HEADER = "acarsMessageHeader";
    public static final String ACTUAL_FUEL = "actualFuel";
    public static final String AIRCRAFT_NUMBER_INDICATOR = "aircraftNumberIndicator";
    public static final String AIRCRAFT_NUMBER = "aircraftNumber";
    public static final String AOC_APPL_ID = "aocApplID";
    public static final String APU_START = "APUStart";
    public static final String APU_START_P3 = "APUStartP3";
    public static final String APU_START_P5 = "APUStartP5";
    public static final String APU_STOP = "APUStop";

    public static final String CAPTAIN_ID = "captainID";
    public static final String CAPTAIN1_ID = "captain1Id";
    public static final String CAPTAIN2_ID = "captain2Id";
    public static final String CREATE_TIMESTAMP = "createTimestamp";

    public static final String DELAY_CODE = "delayCode";
    public static final String DESTINATION_IATA_AIRPORT_CODE = "destinationIataAirportCode";
    public static final String DESTINATION_STATION = "destinationStation";
    public static final String DE_ICE_FLAG = "deIceFlag";
    public static final String DIVERSION_CODE = "diversionCode";

    public static final String ERROR = "error";
    public static final String ESTIMATED_ETA = "estimatedEta";
    public static final String ESTIMATED_OFF_TIME = "estimatedOffTime";
    public static final String ESTIMATED_OUT_TIME = "estimatedOutTime";
    public static final String ETA = "eta";

    public static final String FIRST_OFFICER_ID = "firstOfficerID";
    public static final String FIRST_OFFICER1_ID = "firstOfficer1Id";
    public static final String FIRST_OFFICER2_ID = "firstOfficer2Id";
    public static final String FIRST_REPORT_FLAG = "firstReportFlag";
    public static final String FLIGHTLEG_DATE = "firstFlightLegDate";
    public static final String FREE_TEXT = "freeText";
    public static final String FUEL_ADDED = "fuelAdded";

    public static final String ID = "id";
    public static final String IN_EVENT_TIME = "inEventTime";

    public static final String LANDING_CATEGORY = "landingCategory";
    public static final String LANDING_OFFICER_CODE = "landingOfficerCode";
    public static final String LANDING_RUNWAY = "landingRunway";
    public static final String LOG_PAGE_NUMBER = "logPageNumber";

    public static final String MANUAL_INITIALIZATION = "isManualInitialization";
    public static final String FLIGHT_DATE = "flightDate";
    public static final String MESSAGE_FLIGHT_NUMBER = "messageFlightNumber";
    public static final String MESSAGE_REPAIRED_STATUS = "messageRepairedStatus";
    public static final String MESSAGE_SMI = "messageSMI";
    public static final String MESSAGE_TIME = "messageTime";
    public static final String MSG_FLIGHT_NUMBER = "msgFlightNumber";
    public static final String MX_DESCRIPANCY = "mxDescripency";

    public static final String NEW_REGION_CODE = "newRegionCode";
    public static final String NOTAMS_SW = "notamsSwitch";
    public static final String NUMBER_OF_LANDING = "numberOfLandings";

    public static final String OFF_EVENT_TIME = "offEventTime";
    public static final String ON_EVENT_TIME = "onEventTime";
    public static final String OOOI_STATE = "oooiState";
    public static final String ORIGIN_IATA_AIRPORT_CODE = "originIataAirportCode";
    public static final String ORIGINAL_DESTINATION_STATION = "originalDestinationStation";
    public static final String ORIGINAL_MESSAGE = "originalMessage";
    public static final String ORIGINATION_STATION = "originationStation";
    public static final String OTHER_MESSAGE_TEXT = "otherMessageText";
    public static final String OUT_EVENT_TIME = "outEventTime";

    public static final String PLANNED_FUEL = "plannedFuel";

    public static final String RADAR_REPORT_SW = "radarReportSwitch";
    public static final String REPAIRED_RAW_MESSAGE = "repairedRawMessage";
    public static final String REQUESTED_DEPARTURE_VALUE = "reqDepartureTime";

    public static final String CURRENT_IN_FUEL = "currentInFuel";
    public static final String PREVIOUS_IN_FUEL = "previousInFuel";
    public static final String CURRENT_OUT_FUEL = "currentOutFuel";
    public static final String CURRENT_OFF_FUEL = "currentOffFuel";
    public static final String MAX_POWER_TAKEOFF = "maxPowerTakeoff";
    public static final String OIL_ADDED_TO_ENGINE_1 = "oilAddedEng1";
    public static final String OIL_ADDED_TO_ENGINE_2 = "oilAddedEng2";
    public static final String OIL_ADDED_TO_ENGINE_3 = "oilAddedEng3";
    public static final String OIL_ADDED_TO_ENGINE_4 = "oilAddedEng4";
    public static final String RESET_TIME = "resetTime";
    public static final String RUNWAY_VISIBLE_RANGE = "runwayVisibleRange";
    public static final String RUNWAY_VISIBLE_RANGE_SIGN = "runwayVisibleRangeSign";

    public static final String SECOND_OFFICER_ID = "secondOfficerID";
    public static final String SECOND_RELIEF_OFFICER_ID = "secondOrReliefOfficerId";
    public static final String SIGMENT_SW = "sigmentSwitch";
    public static final String SURFACE_ANALYSIS_SW = "surfaceAnalysisSwitch";

    public static final String TAKEOFF_GROSS_WEIGHT = "takeoffGrossWeight";
    public static final String TAKEOFF_RUNWAY = "takeoffRunway";
    public static final String TERMINAL_FORECAST_SW = "terminalForecastSwitch";
    public static final String TOTAL_FUEL = "totalFuel";

    public static final String UPDATE_TIME_PERIOD = "updateTimePeriod";
    public static final String UPDATE_TIMESTAMP = "updateTimestamp";

    public static final String WINDS_ALOFT_SW = "windsAloftSwitch";
    public static final String WORSE_THAN_PLAN_CODE = "worseThanPlanCode";
    public static final String WXR_WATCH_SW = "wxrWatchSwitch";
    public static final String ALTIMETER = "altimeter";
    public static final String NUMBER_OF_ACM = "numberOfACM";
    public static final String CANNED_CODE = "cannedCode";
    public static final String MX_CODE = "mxCode";
    public static final String OIL_ADDED_TO_APU = "oilAddedToAPU";
    public static final String APU_TIME = "apuTime";
    public static final String PUSH_BACK_TIME = "pushBackTime";
    public static final String DOOR_OPEN_TIME = "doorOpenTime";
    public static final String APU_CYCLE = "apuCycle";
    public static final String OOOI_TIME_FLAG = "oooiTimeFlag";
    public static final String TAKE_OFF_OFFICER_CODE = "takeOffOfficerCode";
    public static final String SAT_UNSAT_REASON_CODE = "satUnsatReasonCode";
    public static final String SET_DISCONNECTED_ALTITUDE = "setDisconnectedAltitue";
    public static final String SET_DEPARTURE_DELAY_DETAILS = "SetDepartureDelayDetails";
    public static final String DELAY_PERIOD = "delayPeriod";

    public static final String PRIORITY_QU = "QU";
    public static final String DESTINATION_ADDRESS_SDFAD5X = "SDFAD5X";
    public static final String ORIGIN_ADDRESS_SDFAS5X = "SDFAS5X";
    public static final String ORIGIN_ADDRESS_SDFAI5X = "SDFAI5X";

    // Rest Call QueryParam Keys
    public static final String START_TIME_RANGE_SCHEDULED_DEPT = "startScheduledDepartureTimeRange";
    public static final String END_TIME_RANGE_SCHEDULED_DEPT = "endScheduledDepartureTimeRange";

    // Other Constants Used across Modules
    public static final String CREATE_UPLK_FOR_M37_CERTIFICATION = "M37StopReminder";
    public static final String WHERE = " where ";
    public static final String AND = " and ";
    public static final String BETWEEN = " between ";
    public static final String EQUALS = " = ";
    public static final String KEY_SEPERATOR = "::";

}
