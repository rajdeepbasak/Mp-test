/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class AcarsMessageHeader implements MessageHeader {

    private String priority;
    private String destinationAddress;
    private String originAddress;
    private String dateOfCreation;
    private String timeOfCreation;
    private String month;
    private String year;
    private String smi;
    private String flightDetailIndicator;
    private String flightNumber;
    private String aircraftRegistrationNumberIndicator;
    private String aircraftRegistrationNumber;
    private String unknownFieldIndicator;
    private String unknownField;
    private String dataLinkIndicator;
    private String serviceProviderId;
    private String groundStation;
    private String currentDate;
    private String currentTime;
    private String messageSequenceNumber;

}
