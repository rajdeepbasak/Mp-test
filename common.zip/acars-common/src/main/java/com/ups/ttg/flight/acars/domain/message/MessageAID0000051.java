package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

/**
 * @author Arpit MessageAID0000051 structure to store values comes in
 *         MessageAID0000051 messages
 */
@Data
public class MessageAID0000051 implements AcarsMessage, MessageHeader {
    @JsonIgnore
    private AcarsMessageHeader acarsMessageHeader;

    private String messageSeqNumber;
    private String messageId;
    private String messageTimestamp;
    private String carCode;
    private String flightNumberForMsg;
    private String flightDate;
    private String flightOrigin;
    private String flightDestination;
    private String flightScheduledDepartureDate;
    private String flightScheduledDepartureTime;
    private String flightScheduledArrivalDate;
    private String flightScheduledArrivalTime;
    private String aircraftRegNumber;
    private String weightLimitId;
    private String weightLimitAmount;
    private String alertType;
    private String freeText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
