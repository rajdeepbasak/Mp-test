package com.ups.ttg.flight.acars.domain;

import lombok.Data;

/**
 * This is POJO class for delay code details
 * 
 * @author 509202
 *
 */
@Data
public class StationDetails extends ReferenceWrapper{

    private String stationCode;
    private String StationShortCode;
}
