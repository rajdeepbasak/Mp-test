package com.ups.ttg.flight.acars.domain;

import lombok.Data;

@Data
public class ActiveFlightDetails {
    private String flightNumber;
    private String flightDate;
    private String aircraftRegistrationNumber;
    private String origin;
    private String destination;
    private String scheduleDepartureTime;
    private String msgReceivedTime;
    private Long enRouteValue;
}
