package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author Rajdeep M4G structure to store values comes in M4G messages
 */
@Data
public class MessageM4G implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
