package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

@Data
public class MessageM3E implements AcarsMessage, MessageHeader {

    private AcarsMessageHeader acarsMessageHeader;

    private String flightDate;
    private String messageTime;
    private String flightSuffix;
    private String firstFlightLegDate;
    private String originationStation;
    private String destinationStation;
    private String cannedMessageCode;
    private String freeText;
    private String otherMessageText;

    @Override
    public MessageHeader getHeader() {
        return acarsMessageHeader;
    }

}
