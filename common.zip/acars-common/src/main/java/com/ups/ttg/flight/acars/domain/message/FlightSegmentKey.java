/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import lombok.Data;

/**
 * @author 482800
 *
 */
@Data
public class FlightSegmentKey {

    private String movementNumber;
    private String movementIdentificationDate;
    private String originIataAirportCode;
    private String keyDistinguishingNumber;

}
