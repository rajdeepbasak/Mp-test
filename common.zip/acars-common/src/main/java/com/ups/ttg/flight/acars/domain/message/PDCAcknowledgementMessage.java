/*
 * <p>
 * The use, disclosure, reproduction, modification, transfer, or transmittal of this work for any purpose in any form or by
 * any means without the written permission of United Parcel Service is strictly prohibited.Confidential, Unpublished Property
 * of United Parcel Service. Use and Distribution Limited Solely to Authorized Personnel.
 * <p>
 * Copyright 2017 United Parcel Service of America, Inc. All Rights Reserved.
 */

package com.ups.ttg.flight.acars.domain.message;

import com.ups.ttg.flight.acars.domain.message.AcarsMessageHeader;

import lombok.Data;

@Data
public class PDCAcknowledgementMessage {

    private AcarsMessageHeader acarsMessageHeader;
	private String flightNumber;
	private String sequenceId;
	private String participationCode;
	private String aircraftRegistrationNumber;
	private String proposedTimeOfDeparture;
	
}
