/**
 * 
 */
package com.ups.ttg.flight.acars.domain.message;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author KUNAL
 *
 */
public interface AcarsMessage {
    public static int MSG_START_INDEX = 80;

    @JsonIgnore
    MessageHeader getHeader();

}
